"use client"

import { useState } from "react"
import { User } from "lucide-react"
import { InterviewSetup } from "@/components/interview-setup"
import { InterviewChat } from "@/components/interview-chat"
import { InterviewSummary } from "@/components/interview-summary"
import { motion, AnimatePresence } from "framer-motion"

type InterviewStage = "setup" | "interview" | "summary"

interface InterviewData {
  resume: string
  jobDescription: string
  candidateName: string
  position: string
}

export default function InterviewAgent() {
  const [stage, setStage] = useState<InterviewStage>("setup")
  const [interviewData, setInterviewData] = useState<InterviewData | null>(null)
  const [interviewResults, setInterviewResults] = useState<any>(null)

  const handleStartInterview = (data: InterviewData) => {
    setInterviewData(data)
    setStage("interview")
  }

  const handleInterviewComplete = (results: any) => {
    setInterviewResults(results)
    setStage("summary")
  }

  const handleRestart = () => {
    setStage("setup")
    setInterviewData(null)
    setInterviewResults(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50"
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  AI Interview Agent
                </h1>
                <p className="text-sm text-gray-600">Intelligent candidate screening system</p>
              </div>
            </div>

            {/* Stage Indicator */}
            <div className="flex items-center space-x-2">
              {["setup", "interview", "summary"].map((s, index) => (
                <div key={s} className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
                      stage === s
                        ? "bg-blue-600 text-white shadow-lg"
                        : index < ["setup", "interview", "summary"].indexOf(stage)
                          ? "bg-green-500 text-white"
                          : "bg-gray-200 text-gray-500"
                    }`}
                  >
                    {index + 1}
                  </div>
                  {index < 2 && (
                    <div
                      className={`w-8 h-0.5 mx-2 transition-all duration-300 ${
                        index < ["setup", "interview", "summary"].indexOf(stage) ? "bg-green-500" : "bg-gray-200"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {stage === "setup" && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
            >
              <InterviewSetup onStartInterview={handleStartInterview} />
            </motion.div>
          )}

          {stage === "interview" && interviewData && (
            <motion.div
              key="interview"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
            >
              <InterviewChat interviewData={interviewData} onComplete={handleInterviewComplete} />
            </motion.div>
          )}

          {stage === "summary" && interviewResults && (
            <motion.div
              key="summary"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
            >
              <InterviewSummary results={interviewResults} interviewData={interviewData!} onRestart={handleRestart} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  )
}
