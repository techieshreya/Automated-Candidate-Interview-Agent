"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle, TrendingUp, TrendingDown, RotateCcw, Download, Share } from "lucide-react"
import { motion } from "framer-motion"

interface InterviewSummaryProps {
  results: {
    totalQuestions: number
    categories: string[]
    responses: any[]
    aiQuestions: any[]
    overallScore: number
    technicalScore: number
    behavioralScore: number
    communicationScore: number
    strengths: string[]
    improvements: string[]
    recommendation: string
  }
  interviewData: {
    candidateName: string
    position: string
  }
  onRestart: () => void
}

export function InterviewSummary({ results, interviewData, onRestart }: InterviewSummaryProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreBg = (score: number) => {
    if (score >= 80) return "bg-green-100"
    if (score >= 60) return "bg-yellow-100"
    return "bg-red-100"
  }

  const getRecommendationColor = (recommendation: string) => {
    if (recommendation.includes("Proceed")) return "bg-green-100 text-green-800"
    if (recommendation.includes("Consider")) return "bg-yellow-100 text-yellow-800"
    return "bg-red-100 text-red-800"
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="border-0 shadow-xl bg-gradient-to-r from-green-600 to-blue-600 text-white">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center space-x-3">
              <CheckCircle className="w-8 h-8" />
              <span>Interview Complete!</span>
            </CardTitle>
            <p className="text-green-100">
              {interviewData.candidateName} has completed the screening for {interviewData.position}
            </p>
          </CardHeader>
        </Card>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Overall Score */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-1"
        >
          <Card className="shadow-lg h-full">
            <CardHeader>
              <CardTitle className="text-center">Overall Score</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className={`text-6xl font-bold ${getScoreColor(results.overallScore)}`}>{results.overallScore}</div>
              <div className="text-gray-600">out of 100</div>
              <Badge className={getRecommendationColor(results.recommendation)}>{results.recommendation}</Badge>
            </CardContent>
          </Card>
        </motion.div>

        {/* Detailed Scores */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2"
        >
          <Card className="shadow-lg h-full">
            <CardHeader>
              <CardTitle>Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {[
                { label: "Technical Skills", score: results.technicalScore },
                { label: "Behavioral Response", score: results.behavioralScore },
                { label: "Communication", score: results.communicationScore },
              ].map((item, index) => (
                <div key={item.label} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{item.label}</span>
                    <span className={`font-bold ${getScoreColor(item.score)}`}>{item.score}/100</span>
                  </div>
                  <Progress value={item.score} className="h-3" />
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Strengths */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="shadow-lg h-full">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-green-700">
                <TrendingUp className="w-5 h-5" />
                <span>Key Strengths</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {results.strengths.map((strength, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    className="flex items-start space-x-3"
                  >
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{strength}</span>
                  </motion.li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        {/* Areas for Improvement */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="shadow-lg h-full">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-orange-700">
                <TrendingDown className="w-5 h-5" />
                <span>Areas for Improvement</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {results.improvements.map((improvement, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                    className="flex items-start space-x-3"
                  >
                    <XCircle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{improvement}</span>
                  </motion.li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Interview Statistics */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Interview Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{results.totalQuestions}</div>
                <div className="text-sm text-gray-600">Questions Asked</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{results.responses.length}</div>
                <div className="text-sm text-gray-600">Responses Given</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{results.categories.length}</div>
                <div className="text-sm text-gray-600">Categories Covered</div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">~25</div>
                <div className="text-sm text-gray-600">Minutes Duration</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="flex justify-center space-x-4"
      >
        <Button onClick={onRestart} variant="outline" size="lg">
          <RotateCcw className="w-5 h-5 mr-2" />
          New Interview
        </Button>
        <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
          <Download className="w-5 h-5 mr-2" />
          Download Report
        </Button>
        <Button variant="outline" size="lg">
          <Share className="w-5 h-5 mr-2" />
          Share Results
        </Button>
      </motion.div>
    </div>
  )
}
