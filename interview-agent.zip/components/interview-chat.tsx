"use client"

import { useState, useEffect, useRef } from "react"
import { useChat } from "ai/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Mic, MicOff, Send, Bot, User, Volume2, VolumeX } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface InterviewChatProps {
  interviewData: {
    resume: string
    jobDescription: string
    candidateName: string
    position: string
  }
  onComplete: (results: any) => void
}

export function InterviewChat({ interviewData, onComplete }: InterviewChatProps) {
  const [isVoiceMode, setIsVoiceMode] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [questionCount, setQuestionCount] = useState(0)
  const [currentCategory, setCurrentCategory] = useState("Introduction")
  const recognitionRef = useRef<any>(null)
  const synthRef = useRef<any>(null)

  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/interview",
    initialMessages: [
      {
        id: "1",
        role: "assistant",
        content: `Hello ${interviewData.candidateName}! I'm your AI interviewer today. I've reviewed your resume and the job description for the ${interviewData.position} position. 

I'll be conducting a comprehensive screening interview covering technical skills, behavioral questions, and situational scenarios. We can do this via text or voice - whatever you're more comfortable with.

Let's start with a simple question: Can you tell me a bit about yourself and what interests you most about this position?`,
      },
    ],
    onFinish: (message) => {
      setQuestionCount((prev) => prev + 1)

      // Determine question category based on content
      const content = message.content.toLowerCase()
      if (content.includes("technical") || content.includes("code") || content.includes("programming")) {
        setCurrentCategory("Technical")
      } else if (content.includes("team") || content.includes("conflict") || content.includes("challenge")) {
        setCurrentCategory("Behavioral")
      } else if (content.includes("scenario") || content.includes("situation") || content.includes("would you")) {
        setCurrentCategory("Situational")
      }

      // Auto-complete after 8 questions
      if (questionCount >= 7) {
        setTimeout(() => {
          completeInterview()
        }, 2000)
      }

      // Text-to-speech for voice mode
      if (isVoiceMode && "speechSynthesis" in window) {
        const utterance = new SpeechSynthesisUtterance(message.content)
        utterance.rate = 0.9
        utterance.pitch = 1
        utterance.onstart = () => setIsSpeaking(true)
        utterance.onend = () => setIsSpeaking(false)
        speechSynthesis.speak(utterance)
      }
    },
  })

  const completeInterview = () => {
    const results = {
      totalQuestions: questionCount + 1,
      categories: ["Introduction", "Technical", "Behavioral", "Situational"],
      responses: messages.filter((m) => m.role === "user"),
      aiQuestions: messages.filter((m) => m.role === "assistant"),
      overallScore: Math.floor(Math.random() * 30) + 70, // Demo score
      technicalScore: Math.floor(Math.random() * 20) + 75,
      behavioralScore: Math.floor(Math.random() * 25) + 70,
      communicationScore: Math.floor(Math.random() * 15) + 80,
      strengths: [
        "Strong technical background in React and TypeScript",
        "Good communication skills",
        "Relevant experience with modern frontend tools",
        "Shows enthusiasm for the role",
      ],
      improvements: [
        "Could provide more specific examples",
        "Consider elaborating on leadership experience",
        "Demonstrate more knowledge of testing practices",
      ],
      recommendation: "Proceed to next round",
    }
    onComplete(results)
  }

  // Voice recognition setup
  useEffect(() => {
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = false
      recognitionRef.current.interimResults = false
      recognitionRef.current.lang = "en-US"

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript
        handleInputChange({ target: { value: transcript } } as any)
        setIsListening(false)
      }

      recognitionRef.current.onerror = () => {
        setIsListening(false)
      }

      recognitionRef.current.onend = () => {
        setIsListening(false)
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [handleInputChange])

  const toggleVoiceMode = () => {
    setIsVoiceMode(!isVoiceMode)
    if (isSpeaking) {
      speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setIsListening(true)
      recognitionRef.current.start()
    }
  }

  const stopSpeaking = () => {
    if ("speechSynthesis" in window) {
      speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const progress = Math.min((questionCount / 8) * 100, 100)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Interview Progress */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="shadow-lg">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Interview Progress</CardTitle>
              <div className="flex items-center space-x-4">
                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                  {currentCategory}
                </Badge>
                <Badge variant="secondary">Question {questionCount + 1}/8</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Progress</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Chat Interface */}
      <Card className="shadow-xl">
        <CardHeader className="border-b">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Bot className="w-6 h-6 text-blue-600" />
              <span>AI Interviewer</span>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant={isVoiceMode ? "default" : "outline"}
                size="sm"
                onClick={toggleVoiceMode}
                className={isVoiceMode ? "bg-green-600 hover:bg-green-700" : ""}
              >
                {isVoiceMode ? <Volume2 className="w-4 h-4 mr-2" /> : <VolumeX className="w-4 h-4 mr-2" />}
                {isVoiceMode ? "Voice Mode" : "Text Mode"}
              </Button>
              {isSpeaking && (
                <Button variant="outline" size="sm" onClick={stopSpeaking}>
                  Stop Speaking
                </Button>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {/* Messages */}
          <div className="h-[500px] overflow-y-auto p-6 space-y-4">
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`flex items-start space-x-3 max-w-[80%] ${
                      message.role === "user" ? "flex-row-reverse space-x-reverse" : ""
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        message.role === "user" ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
                      }`}
                    >
                      {message.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                    </div>
                    <div
                      className={`rounded-lg p-4 ${
                        message.role === "user" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isLoading && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-gray-600" />
                  </div>
                  <div className="bg-gray-100 rounded-lg p-4">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Input Area */}
          <div className="border-t p-4">
            <form onSubmit={handleSubmit} className="flex space-x-2">
              <Input
                value={input}
                onChange={handleInputChange}
                placeholder={isVoiceMode ? "Speak your answer or type here..." : "Type your answer here..."}
                className="flex-1"
                disabled={isLoading}
              />
              {isVoiceMode && (
                <Button
                  type="button"
                  variant={isListening ? "destructive" : "outline"}
                  size="icon"
                  onClick={startListening}
                  disabled={isLoading || isSpeaking}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </Button>
              )}
              <Button type="submit" disabled={isLoading || !input.trim()}>
                <Send className="w-4 h-4" />
              </Button>
            </form>
            {isListening && (
              <p className="text-sm text-blue-600 mt-2 flex items-center">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
                Listening... Speak now
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
