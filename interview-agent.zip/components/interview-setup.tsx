"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Upload, FileText, Briefcase, Play, Sparkles } from "lucide-react"
import { motion } from "framer-motion"

interface InterviewSetupProps {
  onStartInterview: (data: {
    resume: string
    jobDescription: string
    candidateName: string
    position: string
  }) => void
}

export function InterviewSetup({ onStartInterview }: InterviewSetupProps) {
  const [candidateName, setCandidateName] = useState("Sarah Johnson")
  const [position, setPosition] = useState("Senior Frontend Developer")
  const [resume, setResume] = useState(`SARAH JOHNSON
Senior Frontend Developer | 5+ Years Experience

EXPERIENCE:
• Senior Frontend Developer at TechCorp (2021-Present)
  - Led development of React-based dashboard serving 10k+ users
  - Implemented responsive design patterns and accessibility standards
  - Mentored junior developers and conducted code reviews

• Frontend Developer at StartupXYZ (2019-2021)
  - Built customer-facing web applications using React and TypeScript
  - Collaborated with UX team to implement pixel-perfect designs
  - Optimized application performance, reducing load times by 40%

SKILLS:
• Languages: JavaScript, TypeScript, HTML5, CSS3
• Frameworks: React, Next.js, Vue.js, Angular
• Tools: Git, Webpack, Jest, Cypress
• Design: Figma, Adobe Creative Suite

EDUCATION:
• Bachelor of Computer Science, University of Technology (2019)`)

  const [jobDescription, setJobDescription] = useState(`SENIOR FRONTEND DEVELOPER

We are seeking a talented Senior Frontend Developer to join our growing team. The ideal candidate will have extensive experience with modern JavaScript frameworks and a passion for creating exceptional user experiences.

RESPONSIBILITIES:
• Develop and maintain complex web applications using React and TypeScript
• Collaborate with designers and backend developers to implement new features
• Optimize applications for maximum speed and scalability
• Mentor junior developers and participate in code reviews
• Stay up-to-date with emerging technologies and best practices

REQUIREMENTS:
• 5+ years of experience in frontend development
• Expert knowledge of React, JavaScript, and TypeScript
• Experience with state management libraries (Redux, Zustand)
• Strong understanding of responsive design and CSS frameworks
• Experience with testing frameworks (Jest, Cypress)
• Excellent communication and teamwork skills
• Bachelor's degree in Computer Science or related field

NICE TO HAVE:
• Experience with Next.js and server-side rendering
• Knowledge of GraphQL and modern API integration
• Experience with design systems and component libraries
• Understanding of web accessibility standards`)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onStartInterview({
      candidateName,
      position,
      resume,
      jobDescription,
    })
  }

  const loadDemoData = () => {
    setCandidateName("Sarah Johnson")
    setPosition("Senior Frontend Developer")
    // Demo data is already loaded by default
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto space-y-6">
      {/* Welcome Card */}
      <Card className="border-0 shadow-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center space-x-3">
            <Sparkles className="w-8 h-8" />
            <span>Welcome to AI Interview Agent</span>
          </CardTitle>
          <p className="text-blue-100">
            Our intelligent system will analyze the candidate's resume and job requirements to conduct a comprehensive
            screening interview.
          </p>
        </CardHeader>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Candidate Information */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
            <Card className="h-full shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <span>Candidate Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="candidateName">Candidate Name</Label>
                  <Input
                    id="candidateName"
                    value={candidateName}
                    onChange={(e) => setCandidateName(e.target.value)}
                    placeholder="Enter candidate name"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="position">Position</Label>
                  <Input
                    id="position"
                    value={position}
                    onChange={(e) => setPosition(e.target.value)}
                    placeholder="Enter position title"
                    className="mt-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Demo Data */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
            <Card className="h-full shadow-lg hover:shadow-xl transition-shadow duration-300 border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-green-700">
                  <Sparkles className="w-5 h-5" />
                  <span>Demo Ready</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-green-600 mb-4">
                  We've pre-loaded demo data for Sarah Johnson applying for a Senior Frontend Developer position.
                </p>
                <Button
                  type="button"
                  onClick={loadDemoData}
                  variant="outline"
                  className="w-full border-green-300 text-green-700 hover:bg-green-100 bg-transparent"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Use Demo Data
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Resume Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-600" />
                <span>Resume Content</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={resume}
                onChange={(e) => setResume(e.target.value)}
                placeholder="Paste the candidate's resume here..."
                className="min-h-[200px] font-mono text-sm"
              />
            </CardContent>
          </Card>
        </motion.div>

        {/* Job Description Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-purple-600" />
                <span>Job Description</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                placeholder="Paste the job description here..."
                className="min-h-[200px] font-mono text-sm"
              />
            </CardContent>
          </Card>
        </motion.div>

        {/* Start Interview Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex justify-center"
        >
          <Button
            type="submit"
            size="lg"
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <Play className="w-5 h-5 mr-2" />
            Start AI Interview
          </Button>
        </motion.div>
      </form>
    </motion.div>
  )
}
